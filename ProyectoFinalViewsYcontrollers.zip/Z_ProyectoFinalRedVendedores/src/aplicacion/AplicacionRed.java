package aplicacion;

import javafx.application.Application;
import javafx.stage.Stage;

public class AplicacionRed extends Application {

	@Override
	public void start(Stage primaryStage) throws Exception {
		
		
	}
	
	

}
