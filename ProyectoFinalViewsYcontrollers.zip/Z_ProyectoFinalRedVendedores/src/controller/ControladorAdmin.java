package controller;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Tab;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import modell.Producto;
import modell.Vendedor;

public class ControladorAdmin {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;
    
//------------------------------------PESTA�A VENDEDOR   tabla de resistro vendedores vista admin-----------------------------------------{

    @FXML
    private TableView<?> tableVendedor;
    
    @FXML
    private TableColumn<Vendedor, String> ColumnaApellidoAdmin;

    @FXML
    private TableColumn<Vendedor, String> ColumnaNOmbVendeAdmin;

    @FXML
    private TableColumn<Vendedor, String> ColumnaTipoProVendeAdmin;

    @FXML
    private TableColumn<Vendedor, String> ColumnacedulaVendedorAdmin;
    
    @FXML
    private TableColumn<Vendedor,String> columnaDireccionVendAdmin;
    
    @FXML
    private Button botonLimpiarVendedorAdmin;

    @FXML
    private Button botonEliminarVendeAdmin;

    @FXML
    private Button botonBuscarVendedorAdmin;

    @FXML
    private Button botonAgregarVendedorAdmin;

    @FXML
    private Button botonActualizarVendedorAdmin;
    
    /**
     * Sets de textfields para manipular los atributos del vendedor en la vista admin -------------{
     * 
     */
    

    @FXML
    private TextField txfNombreVendedorAdmin;

    @FXML
    private TextField txfApellidoVendeAdmin;

    @FXML
    private TextField txfCedulaVendedorAdmin;

    @FXML
    private TextField txfDireccionVendedorAdmin;

    @FXML
    private TextField txfTipoProVendedorAdmin;
    
    /**
     * ----------------------------------------------------------------------------------------------}
     */

//------------------------------------------------------------------------------------------------------------------------}

    /**
     * -------------------TABLA Y TEXTFIELDS PARA GESTIONAR PRODUCTOS VISTA ADMINISTRADOR--------PESTA�A PRODUCTOS -------------{
     */

    @FXML
    private TableView<Producto> tableProductoAdmin;

    @FXML
    private TableColumn<Producto, String> columnaNOmbreProducAdmin;

    @FXML
    private TableColumn<Producto, String> columnaCodigoProducAdmin;

    @FXML
    private TableColumn<Producto, String> columnaCategoriaProducAdmin;

    @FXML
    private TableColumn<Producto, String> columnaPrecioProducAdmin;

    @FXML
    private Button botonAgregarproducAdmin;

    @FXML
    private Button botonEliminarProdAdmin;

    @FXML
    private Button botonActualizarProdAdmin;

    @FXML
    private Button botonLimpiarProductoAdmin;

    @FXML
    private Button botonBuscarProducAdmin;
    
    @FXML
    private ImageView ImagenProductoAdmin;
    
 //Sets de textfields para manipular los atributos de productos en la vista admin -------------{   

    @FXML
    private TextField tdxCodigoProductoAdmin;


    @FXML
    private TextField txfCategoriaProdAdmin;



    @FXML
    private TextField txfImagenProdAdmin;


    @FXML
    private TextField txfPrecioProducAdmin;


    @FXML
    private TextField txfnombProductoAdmin;
//---------------------------------------------------------------------------------------------}

    /**
     * ----------------------------------------------------------------------------------------------}
     */
    
    @FXML
    private Tab pestanaProducto;

    @FXML
    private Tab pestanaVendedor;



    @FXML
    void ActualizarProductoAdminEvent(ActionEvent event) {

    }

    @FXML
    void ActualizarVendedorAdminEvent(ActionEvent event) {

    }

    @FXML
    void AgregarProductoAdminEvent(ActionEvent event) {

    }

    @FXML
    void AgregarVendedorAdminEvent(ActionEvent event) {

    }

    @FXML
    void BuscarProductoAdminEvent(ActionEvent event) {

    }

    @FXML
    void BuscarVendedorAdminEvent(ActionEvent event) {

    }

    @FXML
    void EliminarProductoAdminEvent(ActionEvent event) {

    }

    @FXML
    void EliminarVendedorAdminEvent(ActionEvent event) {

    }

    @FXML
    void LimpiarProductoAdminEvent(ActionEvent event) {

    }

    @FXML
    void LimpiarVendedorAdminEvent(ActionEvent event) {

    }

    @FXML
    void initialize() {
       
    }

}
