package controller;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Tab;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import modell.Producto;

public class ControladorUsuario {
	

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private AnchorPane AnchorPaneVentayAmigo;
	
	/**
	 * ------------------------PESTA�A VENTA DE PRODUCTOS VISTA USUARIO  (TABLA)  ----------------------------{
	 */

    @FXML
    private Tab pestaniaVenta;

    @FXML
    private TableView<Producto> tableProductosVenta;

    @FXML
    private TableColumn<?, ?> ColumnaNombreVenta;

    @FXML
    private TableColumn<?, ?> ColumnaVendedorVenta;

    @FXML
    private TableColumn<?, ?> ColumnaPrecioVenta;

    @FXML
    private Button botonMostrarProductoVenta;

    @FXML
    private Button botonComprarProductoVenta;
	/**
	 * --------------------------------------------------------------------------------------------}
	 */

    /**
	 * ------------------------PESTA�A VENTA DE PRODUCTOS VISTA USUARIO  (MURO)----------------------------{
	 */

    @FXML
    private ImageView imgVenta;

    @FXML
    private Button botonMegustaVenta;

    @FXML
    private Button botonMsjVendedorVenta;

    @FXML
    private TextArea textAreaMensajeVenta;
    
    /**
     * -----------------------------------------------------------------------------------------------------}
     */
    
    
    /**
  	 * ------------------------PESTA�A VENTA DE PRODUCTOS VISTA USUARIO  (COMENTARIOS)----------------------------{
  	 */

    @FXML
    private TextArea txtAreaComentarioVenta;

    @FXML
    private Button botonComentarVenta;
    /**
	 * -----------------------------------------------------------------------------------------------------}
	 */
    
    
    
    /**
     * -----------------------PESTA�A AMIGOS VENDEDORES VISTA USUARIO   (BUSCADOR)---------------------------------{
     */

    @FXML
    private Tab pestaniaAmigos;

    @FXML
    private TextField txtCodigoVendedorAmigo;

    @FXML
    private Button botonBuscarVendedorAmigo;
    
    /**
	 * -----------------------------------------------------------------------------------------------------}
	 */

    /**
     * -----------------------PESTA�A AMIGOS VENDEDORES VISTA USUARIO   (TABLA DE AMIGOS)---------------------------------{
     */

    @FXML
    private TableView<?> tableAmigo;

    @FXML
    private TableColumn<?, ?> columnaCodigoAmigo;

    @FXML
    private TableColumn<?, ?> columnaDireccionAmigo;

    @FXML
    private TableColumn<?, ?> columnaNombreAmigo;

    @FXML
    private TableColumn<?, ?> columnaTelefonoAmigo;

    @FXML
    private TableColumn<?, ?> columnaTipoProdAmigo;
    
    @FXML
    private Button botonActualizarAmigo;

    @FXML
    private Button botonEliminarAmigo;
    /**
	 * -----------------------------------------------------------------------------------------------------}
	 */

    
    /**
     * -------------PESTA�A AMIGOS VENDEDORES VISTA USUARIO   (TABLA DE VENDEDORES TOTALES)---------------------------------{
     */

    @FXML
    private TableView<?> tableVendedorTotal;
    @FXML
    private TableColumn<?, ?> ColumnaCodigoVendedotTo;

    @FXML
    private TableColumn<?, ?> ColumnaDireccionVendedotTo;

    @FXML
    private TableColumn<?, ?> ColumnaNombreVendedotTo;



    @FXML
    private TableColumn<?, ?> ColumnaTelefonoVendedotTo;

    @FXML
    private TableColumn<?, ?> ColumnaTipoProdVendedotTo;
    
    @FXML
    private Button botonAgregarVendedorTo;

    /*
     * --------------------------BUSCADOR DE VENDEDORES TOTALES--------------------------------------------------{
     */
    
    @FXML
    private TextField txfNombreVendedorTo;

    @FXML
    private TextField txfTipoProduVendedorTo;

    @FXML
    private Button botonBuscarNombreVendedorTo;

    @FXML
    private Button botonBuscarTipoProdVendedorTo;
    
    /*
     * -----------------------------------------------------------------------------------------------------------}
     */
    

    /**
	 * -------------------------------------------------------------------------------------------------------------------}
	 */
    @FXML
    void ActualizarAmigoEvent(ActionEvent event) {

    }

    @FXML
    void AgregarVendedorToEvent(ActionEvent event) {

    }

    @FXML
    void BuscarAmigoCodigoEvent(ActionEvent event) {

    }

    @FXML
    void BuscarVendedorNombreEvent(ActionEvent event) {

    }

    @FXML
    void BuscarVendedorTipoProdEvent(ActionEvent event) {

    }

    @FXML
    void ComentarVentaEvent(ActionEvent event) {

    }

    @FXML
    void ComprarProducVentaEvent(ActionEvent event) {

    }

    @FXML
    void EliminarAmigoEvent(ActionEvent event) {

    }

    @FXML
    void MegustaVentaEvent(ActionEvent event) {

    }

    @FXML
    void MostrarProducVentaEvent(ActionEvent event) {

    }

    @FXML
    void MsjVendedorVentaEvent(ActionEvent event) {

    }
    @FXML
    void initialize() {
        
    }

  



    










   



    

}

