package exceptions;

public class productoExeption extends Exception{
    public productoExeption(String el_producto_ya_existe) {
    }
}
