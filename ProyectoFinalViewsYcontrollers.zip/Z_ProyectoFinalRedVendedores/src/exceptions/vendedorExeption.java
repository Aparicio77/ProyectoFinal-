package exceptions;

public class vendedorExeption extends Exception {
    public vendedorExeption(String el_vendedor_existe) {

    }
}
