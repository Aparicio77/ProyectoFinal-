package modell;

public enum EnumTipoAliado {
    XPRODUCTO;

    EnumTipoAliado() {
    }
}
