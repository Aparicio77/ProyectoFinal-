package modell;

public enum EnumEstado {

    VENDIDO,PUBLICADO,CANCELADO;

    @Override
    public String toString() {
        return "EnumEstado{}";
    }
}
